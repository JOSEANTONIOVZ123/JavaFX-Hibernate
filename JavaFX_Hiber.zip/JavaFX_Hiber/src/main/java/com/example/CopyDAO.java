package com.example;
/**
 * DAO para la entidad Copy.
 */
public class CopyDAO {
    public void deleteCopy(Copy copy) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.delete(copy);
        tx.commit();
        session.close();
    }

    public void updateCopy(Copy copy) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.update(copy);
        tx.commit();
        session.close();
    }
}
