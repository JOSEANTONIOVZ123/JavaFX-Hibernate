package com.example;
/**
 * Entidad que representa una copia de una película.
 */
@Entity
@Table(name = "copies")
public class Copy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "movie_id")
    private Movie movie;

    private String status;
    private int quantity;

    // Getters y setters
}
