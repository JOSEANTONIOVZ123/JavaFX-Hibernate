package com.example;
public class MainController implements Initializable {
    @FXML private TableView<Movie> movieTable;
    @FXML private TableColumn<Movie, String> titleColumn;

    private MovieDAO movieDAO = new MovieDAO();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        movieTable.setItems(FXCollections.observableArrayList(movieDAO.getAllMovies()));
    }

    @FXML
    private void handleAddMovie(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/add_movie.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
