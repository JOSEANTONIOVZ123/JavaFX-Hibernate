package com.example;
public class MovieDAO {
    public List<Movie> getAllMovies() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query<Movie> query = session.createQuery("from Movie", Movie.class);
        return query.getResultList();
    }

    public void saveMovie(Movie movie) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(movie);
        tx.commit();
        session.close();
    }
}
