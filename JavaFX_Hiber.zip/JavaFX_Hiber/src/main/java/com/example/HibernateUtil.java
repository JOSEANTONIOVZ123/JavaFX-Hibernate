package com.example;

public class HibernateUtil {
}
