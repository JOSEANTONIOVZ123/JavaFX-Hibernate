package com.example;
@Entity
@Table(name = "movies")
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String genre;
    private int year;

    @OneToMany(mappedBy = "movie", cascade = CascadeType.ALL)
    private List<Copy> copies;

    // Getters y setters
}
