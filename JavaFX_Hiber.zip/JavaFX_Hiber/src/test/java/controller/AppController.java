package controller;

public class AppController {
}
